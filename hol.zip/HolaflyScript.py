# coding=utf-8
import os
import re
import requests
import time
from datetime import datetime
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from collections import defaultdict

class HolaflyAPI:
    def __init__(self, iccid_list, dest=None):
        self.iccid_list = iccid_list
        self.dest = dest
        self.session = self.create_session()

    def create_session(self):
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 502, 503, 504],
            allowed_methods=["GET"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session = requests.Session()
        session.mount("https://", adapter)
        return session

    def fetch_iccid_data(self, iccid):
        url = f"https://customers-api.holafly.com/api/customerCard/getByIccid/{iccid}?includeProvider=true"
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Request for ICCID {iccid} failed: {e}")
            return None

    def fetch_manual_activation(self, user_id, iccid):
        url2 = f"https://customers-api.holafly.com/user/{user_id}/manualActivation/{iccid}"
        try:
            response = self.session.get(url2, timeout=10)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Request for manual activation failed: {e}")
            return None

    def process_iccids(self):
        output_filename = f'holaflyResult-{self.iccid_list[0]}T{self.iccid_list[-1]}-{self.dest or "ALL"}-{datetime.now().strftime("%Y%m%d%H%M%S")}.txt'
        print(output_filename)
        with open(output_filename, 'w', encoding='utf-8') as result_file:
            for iccid in self.iccid_list:
                time.sleep(0.2)
                print("Fetching iccid:", iccid)
                dat = self.fetch_iccid_data(iccid)
                if dat and dat.get('activation_date') is None:
                    if dat.get('consumedData') is not None:
                        if dat.get('consumedData')[0].get('usedData') == 0:
                            print(dat)
                            result = f"{dat.get('iccid')},{dat['destination'].get('en')}_{dat['boundle'].get('en')}"
                            activation_code = self.fetch_manual_activation(dat.get('customer_id'), iccid)
                            if activation_code:
                                print(f"{result},LPA:1${activation_code.get('SMDP')}${activation_code.get('activationCode')}")
                                result_file.write(f"{result},LPA:1${activation_code.get('SMDP')}${activation_code.get('activationCode')}\n")
        if os.path.getsize(output_filename) == 0:
            os.remove(output_filename)
            print(f"Result is empty and file {output_filename} has been deleted.")
        else:
            print(f"Results written to {output_filename}, Finish time: {datetime.now().strftime('%Y%m%d%H%M%S')}")

def select_file():
    txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]
    if not txt_files:
        print("No .txt files found in the current directory.")
        return None
    print("Select a file:")
    for i, file in enumerate(txt_files, 1):
        print(f"{i}. {file}")
    choice = int(input("Enter the number of the file you want to use: "))
    return txt_files[choice - 1]

def select_destination(destinations):
    print("Select a destination (press Enter to process all ICCIDs):")
    for i, (dest, count) in enumerate(destinations.items(), 1):
        print(f"{i}. {dest} ({count} ICCIDs)")
    choice = input("Enter the number of the destination you want to use: ")
    if choice.strip() == "":
        return None
    return list(destinations.keys())[int(choice) - 1]

def get_destinations(filename):
    destinations = defaultdict(int)
    with open(filename, 'r', encoding='utf-8') as file:
        for line in file:
            match = re.match(r'^(89852\d+),\s*([A-Z]{3})', line.strip())
            if match:
                destinations[match.group(2)] += 1
    return destinations

def generate_iccid_range(start_iccid, end_iccid):
    start = int(start_iccid)
    end = int(end_iccid)
    return [str(iccid) for iccid in range(start, end + 1)]

def validate_iccid(iccid):
    if len(iccid) not in [19, 20]:
        return False
    total = 0
    reverse_digits = iccid[::-1]
    for i, digit in enumerate(reverse_digits):
        n = int(digit)
        if i % 2 == 0:
            total += n
        else:
            double = n * 2
            total += double if double < 10 else double - 9
    return total % 10 == 0

def input_iccid(prompt):
    while True:
        iccid = input(prompt)
        if iccid.isdigit():
            if iccid.startswith("89852") and len(iccid) < 20:
                iccid = iccid.ljust(20, '0')
            elif iccid.startswith("894310") and len(iccid) < 19:
                iccid = iccid.ljust(19, '0')
            return iccid
        else:
            print("Invalid input. Please enter a numeric ICCID.")

if __name__ == "__main__":
    while True:
        mode = input("Select mode (1: Select file, 2: Enter ICCID range): ")
        if mode == "1":
            filename = select_file()
            if filename:
                destinations = get_destinations(filename)
                if destinations:
                    dest = select_destination(destinations)
                    iccid_list = []
                    with open(filename, 'r', encoding='utf-8') as file:
                        for line in file:
                            match = re.match(r'^(89852\d+),\s*([A-Z]{3})', line.strip())
                            if match and (dest is None or match.group(2) == dest):
                                iccid_list.append(match.group(1))
                    print(f"Total: {len(iccid_list)}, Dest: {'ALL' if dest is None else dest}")
                    input("*Press 'Enter' to start*")
                    holafly_api = HolaflyAPI(iccid_list, dest)
                    holafly_api.process_iccids()
            break
        elif mode == "2":
            start_iccid = input_iccid("Enter the start ICCID: ")
            end_iccid = input_iccid("Enter the   end ICCID: ")
            if int(start_iccid) > int(end_iccid):
                print("Start ICCID should be less than or equal to End ICCID. Please try again.")
            else:
                iccid_list = generate_iccid_range(start_iccid, end_iccid)
                valid_iccid_list = [iccid for iccid in iccid_list if validate_iccid(iccid)]
                if not valid_iccid_list:
                    print("No valid ICCIDs found in the specified range. Please try again.")
                else:
                    print(f"ICCID range: {start_iccid} - {end_iccid}")
                    print(f"Number of valid ICCIDs: {len(valid_iccid_list)}")
                    input("*Press 'Enter' to start*")
                    holafly_api = HolaflyAPI(valid_iccid_list)
                    holafly_api.process_iccids()
                    break
        else:
            print("Invalid mode selected. Please try again.")
