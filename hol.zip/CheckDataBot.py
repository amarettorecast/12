from email.policy import strict

import httpx
import asyncio
import secrets
import string
import json
import logging
from datetime import datetime
from telegram import Update, Message
from telegram.ext import Application, ContextTypes, MessageHandler, filters, CallbackContext, CommandHandler
from telegram.constants import ParseMode

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Suppress httpx logs
logging.getLogger("httpx").setLevel(logging.WARNING)

# Configuration
config = {
    "password": "4ea9060a6201c04035b9d7bb3a34d4c5",
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0",
    "cmlink_login_url": "https://global.cmlink.com/api/login",
    "cmlink_api_url": "https://global.cmlink.com/api/user-login/ApiGetGws",
    "holafly_api_url": "https://customers-api.holafly.com/api/customerCard/getByIccid/{iccid}?includeProvider=true",
    "telegram_bot_token": "12345678901:ABCDKVKIDKCKJCDF-GhECTTk",
    "channel_id": "@freedataesim",
    "enforce_join_channel": 0
}

token = {
    "accessToken": "1",
    "authorization_value": "1"
}

def validate_iccid(iccid):
    iccid = iccid.replace(" ", "").replace("-", "")
    if len(iccid) not in (19, 20):
        return False
    digits = [int(digit) for digit in iccid]
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    checksum = sum(odd_digits)
    for d in even_digits:
        checksum += sum(divmod(d * 2, 10))
    return checksum % 10 == 0


async def login_get_authorization_key():
    now = datetime.now()
    timestamp = str(int(datetime.timestamp(now))) + "000"
    characters = string.ascii_lowercase + string.digits
    random_string = ''.join(secrets.choice(characters) for _ in range(8))
    data = {
        "code": random_string + timestamp,
        "password": config['password'],
        "timestamp": timestamp
    }
    async with httpx.AsyncClient() as client:
        response = await client.post(config['cmlink_login_url'], data=data, timeout=10)
    content = response.json()
    if content.get('statusCode') == 1:
        token["authorization_value"] = content.get('content')
        logger.info("Authorization key saved")
    logger.info("login_get_authorization_key: %s", content)


async def get_access_token():
    headers = {
        "Authorization": f"Bearer {token['authorization_value']}",
        "User-Agent": config['user_agent']
    }
    data = {
        "url_type": "APP_getAccessToken_SBO",
        "json": "{\"id\":\"8618922393096\",\"type\":104}",
        "method": "https"
    }
    async with httpx.AsyncClient() as client:
        response = await client.post(config['cmlink_api_url'], data=data, timeout=10, headers=headers)
    content = response.json()
    if content.get('description') == "Success":
        token["accessToken"] = content.get('accessToken')
        logger.info("Access token saved")
    else:
        await login_get_authorization_key()
    logger.info("get_access_token: %s", content)


async def get_cmlink_data_bundle(iccid):
    async def fetch_data():
        headers = {
            "Authorization": f"Bearer {token['authorization_value']}",
            "User-Agent": config['user_agent']
        }
        data = {
            "url_type": "APP_getSubedUserDataBundle_SBO",
            "json": json.dumps(
                {"iccid": iccid, "accessToken": token["accessToken"], "language": "1", "beginIndex": 0, "count": 100}),
            "method": "https"
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(config['cmlink_api_url'], data=data, timeout=10, headers=headers)
        return response.json(strict=False)

    content = await fetch_data()
    if content.get("code") != "0000000":
        logger.info("Authorization key expired")
        await login_get_authorization_key()
        content = await fetch_data()
    if content.get("code") in ["1000008", "1000007"]:
        logger.info("Access token expired")
        await get_access_token()
        content = await fetch_data()

    logger.info("get_iccid_data_bundle: %s", content)
    return content

async def get_holafly_card(iccid):
    async with httpx.AsyncClient() as client:
        response = await client.get(config['holafly_api_url'].format(iccid=iccid), timeout=10, headers={"User-Agent": config['user_agent']})
    logger.info("get_holafly_card: %s", response.json(strict=False))
    return response.json(strict=False)

async def handle_message(update: Update, context: CallbackContext) -> None:
    if config['enforce_join_channel']:
        user_id = update.message.from_user.id
        chat_member = await context.bot.get_chat_member(config['channel_id'], user_id)
        if chat_member.status not in ['member', 'administrator', 'creator']:
            await update.message.reply_text('You must subscribe to our channel @freedataesim to use this bot.', reply_to_message_id=update.message.message_id)
            return
    message_text = update.message.text
    if message_text.isnumeric() and message_text.startswith('8985234') and len(message_text) == 20 or message_text.startswith('894310') and len(message_text) == 19:
        if validate_iccid(message_text):
            try:
                if message_text.startswith('8985234'):
                    content = await get_cmlink_data_bundle(message_text)
                    await update.message.reply_text(
                        text=f"```{json.dumps(content.get('userDataBundles')[0] if len(content.get('userDataBundles')) > 0 else json.dumps(content), indent=2, ensure_ascii=False)}```",
                        parse_mode=ParseMode.MARKDOWN,
                        reply_to_message_id=update.message.message_id
                    )
                elif message_text.startswith('894310'):
                    content = await get_holafly_card(message_text)
                    await update.message.reply_text(
                        text=f"```{json.dumps(content, indent=2, ensure_ascii=False)}```",
                        parse_mode=ParseMode.MARKDOWN,
                        reply_to_message_id=update.message.message_id
                    )
            except Exception as e:
                await update.message.reply_text(
                    text=f"```An error occurred: {e}```",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_to_message_id=update.message.message_id
                )
        else:
            await update.message.reply_text('The ICCID you input is invalid', reply_to_message_id=update.message.message_id)

async def start(update: Update, context: CallbackContext) -> None:
    user = update.message.from_user
    welcome_message = f"Welcome, {user.first_name}! Your user ID is {user.id}. Subscribe our channel @freedataesim to start using this bot."
    await update.message.reply_text(welcome_message, reply_to_message_id=update.message.message_id)

def main() -> None:
    application = Application.builder().token(config['telegram_bot_token']).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.run_polling()


if __name__ == '__main__':
    main()
