import httpx
import secrets
import string
import json
import os
import re
from datetime import datetime
import asyncio

use_proxy = False
proxies = "http://127.0.0.1:40000"
token = {"accessToken": "", "authorization_value": ""}

headersUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.0.0"

def calculate_checksum(iccid):
    total = 0
    for i, digit in enumerate(iccid[::-1]):
        n = int(digit)
        if i % 2 == 0:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return (10 - (total % 10)) % 10

def generate_iccids(start_iccid, end_iccid):
    start_iccid = start_iccid[:20].ljust(19, '0')
    end_iccid = end_iccid[:20].ljust(19, '0')

    start, end = int(start_iccid), int(end_iccid)
    return [str(i) + str(calculate_checksum(str(i))) for i in range(start, end + 1)]

def extract_iccids_from_file(filename):
    iccids = []
    pattern = re.compile(r'\b\d{19,20}\b')
    try:
        with open(filename, 'r') as file:
            for line in file:
                match = pattern.search(line)
                if match:
                    iccids.append(match.group())
    except Exception as e:
        print(f"读取文件时出错: {e}")
    return iccids

def get_iccid_input(prompt):
    while True:
        iccid_suffix = input(prompt).strip()
        if re.fullmatch(r'\d{8}', iccid_suffix):
            return f"89852342022{iccid_suffix}"
        else:
            print("输入无效，请输入8位数字。")

def save_iccids_to_file(iccids, filename):
    with open(filename, 'w') as file:
        file.write('\n'.join(iccids))

async def login_get_authorization_key(client):
    timestamp = str(int(datetime.timestamp(datetime.now()))) + "000"
    random_string = ''.join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(8))

    data = {
        "code": random_string + timestamp,
        "password": "4ea9060a6201c04035b9d7bb3a34d4c5",
        "timestamp": timestamp
    }

    response = await client.post("https://global.cmlink.com/api/login", data=data, timeout=10)
    if response.status_code == 403:
        raise Exception(f"请求 {response.url} 失败, 状态码： {response.status_code}.")
    content = response.json(strict=False)
    if content.get('statusCode'):
        token["authorization_value"] = content.get('content')

async def get_access_token(client):
    client.headers.update({
        "Authorization": f"Bearer {token['authorization_value']}",
        "User-Agent": headersUserAgent
    })

    data = {
        "url_type": "APP_getAccessToken_SBO",
        "json": "{\"id\":\"8618922393096\",\"type\":104}",
        "method": "https"
    }
    response = await client.post("https://global.cmlink.com/api/user-login/ApiGetGws", data=data, timeout=10)
    if response.status_code == 403:
        raise Exception(f"请求 {response.url} 失败, 状态码： {response.status_code}.")
    content = response.json(strict=False)
    if content.get('description') == "Success":
        token['accessToken'] = content.get('accessToken')
    else:
        await login_get_authorization_key(client)

async def make_request(client, url, data):
    client.headers.update({
        "Authorization": f"Bearer {token['authorization_value']}",
        "User-Agent": headersUserAgent
    })
    response = await client.post(url, data=data, timeout=10)
    return response.json(strict=False)

async def get_iccid_data_bundle(client, iccid):
    data = {
        "url_type": "APP_getSubedUserDataBundle_SBO",
        "json": json.dumps({"iccid": iccid, "accessToken": token['accessToken'], "language": "1", "beginIndex": 0, "count": 100}),
        "method": "https"
    }
    try:
        content = await make_request(client, "https://global.cmlink.com/api/user-login/ApiGetGws", data)

        if content.get("success") == False:
            print("Authorization key expired")
            await login_get_authorization_key(client)
            await asyncio.sleep(1)
            content = await make_request(client, "https://global.cmlink.com/api/user-login/ApiGetGws", data)

        if content.get("code") in ["1000008", "1000007"]:
            print("accessToken expired")
            await get_access_token(client)
            await asyncio.sleep(1)
            content = await make_request(client, "https://global.cmlink.com/api/user-login/ApiGetGws", data)

        return content, iccid
    except httpx.ConnectTimeout:
        print(f"Request for ICCID {iccid} timed out.")
        return None, iccid
    except Exception as e:
        print(f"Request for ICCID {iccid} failed: {e}")
        return None, iccid

async def process_iccids(client, iccids, result_file):
    for idx, iccid in enumerate(iccids):
        response, iccid = await get_iccid_data_bundle(client, iccid)
        if response:
            try:
                #print(response)
                print(f"总共:{len(iccids)}, 当前:{iccids[idx]}, 剩余:{len(iccids) - idx - 1}")
                if response.get('userDataBundles') and len(response['userDataBundles']) > 0:
                    active_time = response['userDataBundles'][0].get('activeTime')
                    status = response['userDataBundles'][0].get('status')
                    value = response['userDataBundles'][0]["name"][0].get('value')
                    if not active_time and status == 1:
                        print(response)
                        result_file.write(f"{iccid}, {value}\n")
                        print(f"{iccid}, {status}, {value}")
            except Exception as e:
                print(f"Request for ICCID {iccid} failed: {e}")

async def main():
    try:
        async with httpx.AsyncClient(proxy=None if not use_proxy else proxies) as client:
            if use_proxy:
                response = await client.get("https://myip.ipip.net", timeout=10)
                if response.is_success:
                    print("配置代理成功：", response.text)
                else:
                    print("代理请求失败，返回HTTP状态值: ", response.status_code)
            await login_get_authorization_key(client)
            await get_access_token(client)

            while True:
                choice = input("请选择操作方式：\n1. 输入开始和结束的ICCID\n2. 从文件读取ICCID\n(输入1或2，输入0退出): ").strip()
                if choice == '0':
                    print("程序已退出。")
                    return
                elif choice in ['1', '2']:
                    break
                else:
                    print("无效的选择，请重新输入1或2。")

            if choice == '1':
                while True:
                    start_iccid = get_iccid_input("请输入开始的ICCID后8位: 89852342022: ")
                    end_iccid = get_iccid_input("请输入结束的ICCID后8位: 89852342022: ")

                    if start_iccid <= end_iccid:
                        filename = f"iccids-{start_iccid}T{end_iccid}.txt"
                        iccids = generate_iccids(start_iccid, end_iccid)
                        print(f"ICCID范围：{iccids[0]}-{iccids[-1]}\n开始的首3个ICCID: {iccids[:3]}\n结束的末3个ICCID: {iccids[-3:]}\n总共: {len(iccids)}")
                        save_iccids_to_file(iccids, filename)
                        print(f"ICCIDs列表已保存到 {filename}")
                        input("*按回车开始执行*")
                        break
                    else:
                        print("开始的ICCID应该小于或等于结束的ICCID，请重新输入。")

            elif choice == '2':
                while True:
                    txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]
                    if not txt_files:
                        print("当前目录下没有找到 .txt 文件")
                        break
                    else:
                        print("请选择一个文件:")
                        for idx, file in enumerate(txt_files, 1):
                            print(f"{idx}. {file}")
                        file_choice = input("输入文件编号 (输入0退出): ").strip()

                        if file_choice == '0':
                            print("程序已退出。")
                            return
                        elif file_choice.isdigit() and 1 <= int(file_choice) <= len(txt_files):
                            filename = txt_files[int(file_choice) - 1]
                            iccids = extract_iccids_from_file(filename)
                            print(f"从文件 {filename} 读取了 {len(iccids)} 个ICCID")
                            input("*按回车开始执行*")
                            break
                        else:
                            print("无效的选择，请重新输入正确的文件编号。")

            if 'iccids' in locals():
                result_filename = f'cmlinkResult-S{iccids[0]}E{iccids[-1]}-T{datetime.now().strftime("%Y%m%d%H%M")}.txt'
                print(result_filename)
                with open(result_filename, 'w') as result_file:
                    await process_iccids(client, iccids, result_file)
            if os.path.getsize(result_filename) == 0:
                os.remove(result_filename)
                print(f"结果文件 {result_filename} 为空，已删除。")
            else:
                print(f"结果已保存到 {result_filename}\n完成时间：{datetime.now().strftime('%Y%m%d%H%M%S')}")
    except Exception as e:
        print(f"An error occurred: {e}")


if __name__ == "__main__":
    asyncio.run(main())
